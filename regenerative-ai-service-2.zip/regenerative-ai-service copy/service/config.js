"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.config = {
    "service": {
        "port": "8080",
        "clearCummulativeMetricsInterval": 60000
    },
    "imageFromTextService": {
        "url": "https://api.segmind.com/v1/sd1.5-realisticvision",
        "synthesizer": "text-to-image7.p.rapidapi.com"
    },
    "voiceFromTextService": {
        "url": "https://joj-text-to-speech.p.rapidapi.com"
    },
    "chatFromTextService": {
        "url": "https://chatgpt-gpt4-ai-chatbot.p.rapidapi.com/ask"
    },
    "chatFromTextServiceAlt": {
        "url": "https://open-ai25.p.rapidapi.com/ask"
    },
    "sentimentAnalysisFromTextService": {
        "url": "https://sentiment-analysis9.p.rapidapi.com/sentiment"
    },
    "profanityCheckService": {
        "url": "https://neutrinoapi-bad-word-filter.p.rapidapi.com/bad-word-filter"
    },
    "emotionalCheckService": {
        "url": "https://twinword-emotion-analysis-v1.p.rapidapi.com/analyze/"
    }
};
