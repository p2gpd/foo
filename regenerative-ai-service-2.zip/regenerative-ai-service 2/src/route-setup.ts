import {FastifyReply, FastifyRequest} from 'fastify'
import {readiness, liveness, requestCount} from './health-endpoints'
import {generateImageFromText, generateVoiceFromText, generateChatFromText, 
        generateChatFromTextAlt, analyzeSentimentFromText, profanityCheck, 
        emotionalCheck} from './route-handlers'
type ReqParams = { textPrompt: string, profanityDetectionEnabled:boolean, useRedacted:boolean }

export function configureRoutes(server:any) {

    // readiness probe endpoint (called by k8s)
    server.get('/readiness', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info("Incoming request at /readiness")
        readiness(reply)
    })
    
    // readiness probe endpoint (called by k8s)
    server.get('/liveness', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info("Incoming request at /liveness")
        liveness(reply)
    })
    
    // readiness probe endpoint (called by k8s)
    server.get('/request-count', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info("Incoming request at /request-count")
        requestCount(reply)
    })

    // endpoint for generating images from a text prompt
    server.post('/gen-image', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info("Incoming request at /gen-image")
        const reqParams = <ReqParams> request.body
        const result = await generateImageFromText(reqParams.textPrompt, reqParams.profanityDetectionEnabled, reqParams.useRedacted)
        reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(result))
    })

    // endpoint for generating voice from a text prompt
    server.post('/gen-voice', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info('Incoming request at /gen-voice')
        const reqParams = <ReqParams> request.body
        const result = await generateVoiceFromText(reqParams.textPrompt, reply)
        reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(result))
    })
  
    // endpoint for generating chat responses from a text prompt
    server.post('/gen-chat', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info('Incoming request at /gen-chat')
        const reqParams = <ReqParams> request.body
        const result = await generateChatFromText(reqParams.textPrompt, reply)
        reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(result))
    })
  
    // endpoint for generating chat responses from a text prompt
    server.post('/gen-chat-alt', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info('Incoming request at /gen-chat-alt')
        const reqParams = <ReqParams> request.body
        const result = await generateChatFromTextAlt(reqParams.textPrompt, reply)
        reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(result))
    })
  
    // endpoint for sentiment analysis from a text prompt
    server.post('/sentiment', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info('Incoming request at /sentiment')
        const reqParams = <ReqParams> request.body
        const result = await analyzeSentimentFromText(reqParams.textPrompt, reply)
        reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(result))
    })

    // endpoint for obsenity check in a text prompt
    server.post('/obsenity', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info('Incoming request at /obsenity')
        const reqParams = <ReqParams> request.body
        const result = await profanityCheck(reqParams.textPrompt, reply)
        reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(result))
    })

    // endpoint for emotional check in a text prompt
    server.post('/emotion', async (request: FastifyRequest, reply: FastifyReply) => {
        server.log.info('Incoming request at /emotion')
        const reqParams = <ReqParams> request.body
        const result = await emotionalCheck(reqParams.textPrompt, reply)
        reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(result))
    })
}