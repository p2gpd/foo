// health-endpoints.ts

import {FastifyReply} from 'fastify'
import { incrementRequestCount, getRequestCount, serviceMetrics, getTimeScopedRequestCount } from './utils'


export async function readiness (reply: FastifyReply): Promise<any>  {
    return await new Promise<any> ((resolve) => {
        incrementRequestCount()
        reply.send('OK')
    })
}

export async function liveness (reply: FastifyReply): Promise<any>  {
    return await new Promise<any> ((resolve) => {
        incrementRequestCount()
        reply.send('OK')
    })
}

export async function requestCount (reply: FastifyReply): Promise<any>  {
    return await new Promise<any> ((resolve) => {
        let resData = {}
        const xactCount = getRequestCount()
        const timeScopedXactCount = getTimeScopedRequestCount()
        resData = <serviceMetrics> { requestCount: xactCount, timeScopedRequestCount: timeScopedXactCount}
        reply
            .header( 'Content-Type', 'application/json', )
            .send(JSON.stringify(resData))
    })
}

