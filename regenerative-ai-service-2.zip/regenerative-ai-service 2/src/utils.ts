
const apiSecrets = require('./secrets-vault.json') // simulate our secrets vault
import app = require('./config')
import axios from 'axios'
export type profanityCheckResp = {  'bad-words-list':[string],
                                        'censored-content':string,
                                        'bad-words-total':number,
                                        'is-bad':boolean }

export type profanityCheckResponse = {  badWordsList:[string],
                                        censoredContent:string,
                                        badWordsTotal:number,
                                        isBad:boolean }
export type serviceMetrics = {  
    requestCount:number,
    timeScopedRequestCount:number
}
    
let requestCount = 0
let timeScopedRequestCount = 0
let metricsTimer: any;

export async function incrementRequestCount(): Promise<any> {
    return await new Promise<any> ((resolve) => {
        requestCount++
        timeScopedRequestCount++
        return 
    })
}

export function getRequestCount() {
    const xactCount = requestCount
    requestCount = 0 // reset the count
    return xactCount
}

export function getTimeScopedRequestCount() {
    return timeScopedRequestCount
}

export function clearTimeScopedRequestCount() {
    timeScopedRequestCount = 0
    return
}

export function startMetricsManager() {
    metricsTimer = setInterval(clearTimeScopedRequestCount, app.config.service.clearCummulativeMetricsInterval);
}

export async function containsProfanity(textPrompt:string): Promise<profanityCheckResponse> {
    const encodedParams = new URLSearchParams()
    encodedParams.set('content', textPrompt)
    encodedParams.set('censor-character', '*')

    const options = {
        method: 'POST',
        url: app.config.profanityCheckService.url,
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'X-RapidAPI-Key': apiSecrets.rapidApiProfanityCheckKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiProfanityCheckHost
        },
        data: encodedParams,
    }

    return await new Promise<any> ((resolve) => {
        axios.request(options)
        .then((response) => {
            const resp = <profanityCheckResp> response.data
            const result = {  badWordsList: resp['bad-words-list'],
                censoredContent: resp['censored-content'],
                badWordsTotal:resp['bad-words-total'],
                isBad: resp['is-bad'] 
            }
            return result
        })
        .catch((error) => {
            throw error
        })
    })
}

