// route-handlers.ts

import {FastifyReply, FastifyRequest} from 'fastify'
import crypto from 'crypto'
import axios from 'axios'
import { incrementRequestCount } from './utils'
const request = require('request')
import {containsProfanity} from './utils'
import { config } from 'process'
const app = require('./config')  // our services configuration
const apiSecrets = require('./secrets-vault.json') // simulate our secrets vault
export type RegenerativeAIResponse = { data: string }
export type profanityCheckResponse = {  badWordsList:[string],
                                        censoredContent:string,
                                        badWordsTotal:number,
                                        isBad:boolean 
}

export async function generateImageFromText (textPrompt:string, profanityDetectionEnabled:boolean, useRedacted:boolean): Promise<any>  {
    return await new Promise<any> ((resolve) => {
        let resData = {}
        const data =  {
            "prompt": textPrompt,
            "negative_prompt": "(deformed iris, deformed pupils, semi-realistic, cgi, render, sketch, cartoon, drawing, anime), text, cropped, out of frame, worst quality, low quality, jpeg artifacts, ugly, duplicate, morbid, mutilated, extra fingers, mutated hands, poorly drawn hands, poorly drawn face, mutation, deformed, blurry, dehydrated, bad anatomy, bad proportions, extra limbs, cloned face, disfigured, gross proportions, malformed limbs, missing arms, missing legs, extra arms, extra legs, fused fingers, too many fingers, long neck, BadDream, UnrealisticDream",
            "scheduler": "dpmpp_2m",
            "num_inference_steps": 100,
            "guidance_scale": 7.5,
            "samples": 1,
            "seed": 2313248373,
            "img_width": 512,
            "img_height": 512,
            "base64": true
        }

        let options = {
            method: 'post',
            maxBodyLength: Infinity,
            url: app.config.imageFromTextService.url,
            headers: { 
                'Content-Type': 'application/json', 
                'x-api-key': apiSecrets.segmindApiKey
            },
            data : data
        }

        axios.request(options)
        .then((response) => {
            resData = <RegenerativeAIResponse>  {data: response.data.image}
        })
        .catch((error) => {
            resData = <RegenerativeAIResponse>  {data: JSON.stringify(error)}
        })
        .finally(() => {
            incrementRequestCount()
            resolve(resData)
        })
    })
}

export async function generateVoiceFromText (textPrompt: string, reply: FastifyReply): Promise<any>  {
    let resData = {}
    const options = {
        method: 'POST',
        url: app.config.voiceFromTextService.url,
            headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': apiSecrets.rapidApiVoiceKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiVoiceHost
        },
        data: {
            input: {
                text: textPrompt
            },
            voice: {
                languageCode: 'en-US',
                name: 'en-US-News-L',
                ssmlGender: 'FEMALE'
            },
            audioConfig: {
                audioEncoding: 'MP3'
            }
        }
    }

    return await new Promise<any> ((resolve) => {
        axios.request(options)
        .then((response) => {
            resData = <RegenerativeAIResponse>  {data: response.data.audioContent}
        })
        .catch((error) => {
            resData = <RegenerativeAIResponse>  {data: JSON.stringify(error)}
        })
        .finally(() => {
            incrementRequestCount()
            reply
                .header( 'Content-Type', 'application/json', )
                .send(JSON.stringify(resData))
        })
    })
}
  
export async function generateChatFromText (textPrompt: string, reply: FastifyReply): Promise<any>  {
    let resData = {}
    const options = {
      method: 'POST',
      url: app.config.chatFromTextService.url,
      headers: {
          'content-type': 'application/json',
          'X-RapidAPI-Key': apiSecrets.rapidApiChatKey,
          'X-RapidAPI-Host': apiSecrets.rapiAapiChatHost
      },
      data: {
          query: textPrompt
      }
    }
  
    return await new Promise<any> ((resolve) => {
        axios.request(options)
        .then((response) => {
            resData = <RegenerativeAIResponse>  {data: response.data}
        })
        .catch((error) => {
            resData = <RegenerativeAIResponse>  {data: JSON.stringify(error)}
        })
        .finally(() => {
            incrementRequestCount()
            reply
                .header( 'Content-Type', 'application/json', )
                .send(JSON.stringify(resData))
        })
    })
}

export async function generateChatFromTextAlt (textPrompt: string, reply: FastifyReply): Promise<any>  {
    let resData = {}
    const options = {
        method: 'POST',
        url: app.config.chatFromTextServiceAlt.url,
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': apiSecrets.altApiChatKey,
            'X-RapidAPI-Host': apiSecrets.altApiChatHost
        },
        data: {
            query: textPrompt
        }
    }
  
    return await new Promise<any> ((resolve) => {
        axios.request(options)
        .then((response) => {
            resData = <RegenerativeAIResponse>  {data: response.data}
        })
        .catch((error) => {
            resData = <RegenerativeAIResponse>  {data: JSON.stringify(error)}
        })
        .finally(() => {
            incrementRequestCount()
            reply
                .header( 'Content-Type', 'application/json', )
                .send(JSON.stringify(resData))
        })
    })
}

export async function analyzeSentimentFromText(textPrompt: string, reply: FastifyReply): Promise<any>  {
    let resData = {}
    const options = {
        method: 'POST',
        maxBodyLength: Infinity,
        url: app.config.sentimentAnalysisFromTextService.url,
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': apiSecrets.rapidApiSentimentAnalysisKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiSentimentAnalysisHost
        },
        data: [{
            id: crypto.randomUUID({disableEntropyCache : true}),
            language: "en",
            text: textPrompt
        }]
    }
  
    return await new Promise<any> ((resolve) => {
        axios.request(options)
        .then((response) => {
            resData = <RegenerativeAIResponse>  {data: response.data}
        })
        .catch((error) => {
            resData = <RegenerativeAIResponse>  {data: JSON.stringify(error)}
        })
        .finally(() => {
            incrementRequestCount()
            reply
                .header( 'Content-Type', 'application/json', )
                .send(JSON.stringify(resData))
        })
    })   
}

export async function profanityCheck(textPrompt: string, reply: FastifyReply): Promise<any>  {
    let resData = {}
    const encodedParams = new URLSearchParams()
    encodedParams.set('content', textPrompt)
    encodedParams.set('censor-character', '*')

    const options = {
        method: 'POST',
        url: app.config.profanityCheckService.url,
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'X-RapidAPI-Key': apiSecrets.rapidApiProfanityCheckKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiProfanityCheckHost
        },
        data: encodedParams,
    }

    return await new Promise<any> ((resolve) => {
        axios.request(options)
        .then((response) => {
            resData = <RegenerativeAIResponse>  {data: response.data}
        })
        .catch((error) => {
            resData = <RegenerativeAIResponse>  {data: JSON.stringify(error)}
        })
        .finally(() => {
            incrementRequestCount()
            reply
                .header( 'Content-Type', 'application/json', )
                .send(JSON.stringify(resData))
        })
    }) 
}

export async function emotionalCheck(textPrompt: string, reply: FastifyReply): Promise<any>  {
    let resData = {}
    const options = {
        method: 'POST',
        url: app.config.emotionalCheckService.url,
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'X-RapidAPI-Key': apiSecrets.rapidApiEmotionCheckKey,
          'X-RapidAPI-Host': apiSecrets.rapidApiEmotionCheckHost
        },
        form: {
          text: textPrompt
        }
      }
      return await new Promise<any> ((resolve) => {
        request(options, function (error:any, response:any, body:any) {
            if (error) {
                resData = <RegenerativeAIResponse>  {data: JSON.stringify(error)}
            }
            else {
                resData = <RegenerativeAIResponse>  {data:body}
            }
            incrementRequestCount()
            reply.header( 'Content-Type', 'application/json', ).send(JSON.stringify(resData))
        })
    })
}




