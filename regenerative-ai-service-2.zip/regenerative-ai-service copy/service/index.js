"use strict";
// generative-ai-service 
Object.defineProperty(exports, "__esModule", { value: true });
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const fastify_1 = require("fastify");
const route_setup_1 = require("./route-setup");
const app = require("./config"); // our services configuration
const utils_1 = require("./utils");
//setup the fastify comm stack
const { ADDRESS = '0.0.0.0', PORT = app.config.service.port } = process.env; //8080
const server = (0, fastify_1.fastify)({
    logger: { level: 'info' }
});
// setup poc endpoint routes.....
(0, route_setup_1.configureRoutes)(server);
server.addHook('onRequest', (request, reply, done) => {
    server.log.info(`request before routing from ${request.ip}`);
    done();
});
// start the service
server.listen({ host: ADDRESS, port: parseInt(PORT, 10) }, (err, address) => {
    if (err) {
        console.error(err);
        process.exit(1);
    }
    (0, utils_1.startMetricsManager)();
    server.log.info(`Started server at ${address}`);
});
