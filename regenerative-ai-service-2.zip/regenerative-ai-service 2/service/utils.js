"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.containsProfanity = exports.startMetricsManager = exports.clearTimeScopedRequestCount = exports.getTimeScopedRequestCount = exports.getRequestCount = exports.incrementRequestCount = void 0;
const apiSecrets = require('./secrets-vault.json'); // simulate our secrets vault
const app = require("./config");
const axios_1 = __importDefault(require("axios"));
let requestCount = 0;
let timeScopedRequestCount = 0;
let metricsTimer;
async function incrementRequestCount() {
    return await new Promise((resolve) => {
        requestCount++;
        timeScopedRequestCount++;
        return;
    });
}
exports.incrementRequestCount = incrementRequestCount;
function getRequestCount() {
    const xactCount = requestCount;
    requestCount = 0; // reset the count
    return xactCount;
}
exports.getRequestCount = getRequestCount;
function getTimeScopedRequestCount() {
    return timeScopedRequestCount;
}
exports.getTimeScopedRequestCount = getTimeScopedRequestCount;
function clearTimeScopedRequestCount() {
    timeScopedRequestCount = 0;
    return;
}
exports.clearTimeScopedRequestCount = clearTimeScopedRequestCount;
function startMetricsManager() {
    metricsTimer = setInterval(clearTimeScopedRequestCount, app.config.service.clearCummulativeMetricsInterval);
}
exports.startMetricsManager = startMetricsManager;
async function containsProfanity(textPrompt) {
    const encodedParams = new URLSearchParams();
    encodedParams.set('content', textPrompt);
    encodedParams.set('censor-character', '*');
    const options = {
        method: 'POST',
        url: app.config.profanityCheckService.url,
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'X-RapidAPI-Key': apiSecrets.rapidApiProfanityCheckKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiProfanityCheckHost
        },
        data: encodedParams,
    };
    return await new Promise((resolve) => {
        axios_1.default.request(options)
            .then((response) => {
            const resp = response.data;
            const result = { badWordsList: resp['bad-words-list'],
                censoredContent: resp['censored-content'],
                badWordsTotal: resp['bad-words-total'],
                isBad: resp['is-bad']
            };
            return result;
        })
            .catch((error) => {
            throw error;
        });
    });
}
exports.containsProfanity = containsProfanity;
