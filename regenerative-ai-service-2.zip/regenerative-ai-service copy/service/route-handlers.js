"use strict";
// route-handlers.ts
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emotionalCheck = exports.profanityCheck = exports.analyzeSentimentFromText = exports.generateChatFromTextAlt = exports.generateChatFromText = exports.generateVoiceFromText = exports.generateImageFromText = void 0;
const crypto_1 = __importDefault(require("crypto"));
const axios_1 = __importDefault(require("axios"));
const utils_1 = require("./utils");
const request = require('request');
const app = require('./config'); // our services configuration
const apiSecrets = require('./secrets-vault.json'); // simulate our secrets vault
async function generateImageFromText(textPrompt, profanityDetectionEnabled, useRedacted) {
    return await new Promise((resolve) => {
        let resData = {};
        const data = {
            "prompt": textPrompt,
            "negative_prompt": "(deformed iris, deformed pupils, semi-realistic, cgi, render, sketch, cartoon, drawing, anime), text, cropped, out of frame, worst quality, low quality, jpeg artifacts, ugly, duplicate, morbid, mutilated, extra fingers, mutated hands, poorly drawn hands, poorly drawn face, mutation, deformed, blurry, dehydrated, bad anatomy, bad proportions, extra limbs, cloned face, disfigured, gross proportions, malformed limbs, missing arms, missing legs, extra arms, extra legs, fused fingers, too many fingers, long neck, BadDream, UnrealisticDream",
            "scheduler": "dpmpp_2m",
            "num_inference_steps": 100,
            "guidance_scale": 7.5,
            "samples": 1,
            "seed": 2313248373,
            "img_width": 512,
            "img_height": 512,
            "base64": true
        };
        let options = {
            method: 'post',
            maxBodyLength: Infinity,
            url: app.config.imageFromTextService.url,
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiSecrets.segmindApiKey
            },
            data: data
        };
        axios_1.default.request(options)
            .then((response) => {
            resData = { data: response.data.image };
        })
            .catch((error) => {
            resData = { data: JSON.stringify(error) };
        })
            .finally(() => {
            (0, utils_1.incrementRequestCount)();
            resolve(resData);
        });
    });
}
exports.generateImageFromText = generateImageFromText;
async function generateVoiceFromText(textPrompt, reply) {
    let resData = {};
    const options = {
        method: 'POST',
        url: app.config.voiceFromTextService.url,
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': apiSecrets.rapidApiVoiceKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiVoiceHost
        },
        data: {
            input: {
                text: textPrompt
            },
            voice: {
                languageCode: 'en-US',
                name: 'en-US-News-L',
                ssmlGender: 'FEMALE'
            },
            audioConfig: {
                audioEncoding: 'MP3'
            }
        }
    };
    return await new Promise((resolve) => {
        axios_1.default.request(options)
            .then((response) => {
            resData = { data: response.data.audioContent };
        })
            .catch((error) => {
            resData = { data: JSON.stringify(error) };
        })
            .finally(() => {
            (0, utils_1.incrementRequestCount)();
            reply
                .header('Content-Type', 'application/json')
                .send(JSON.stringify(resData));
        });
    });
}
exports.generateVoiceFromText = generateVoiceFromText;
async function generateChatFromText(textPrompt, reply) {
    let resData = {};
    const options = {
        method: 'POST',
        url: app.config.chatFromTextService.url,
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': apiSecrets.rapidApiChatKey,
            'X-RapidAPI-Host': apiSecrets.rapiAapiChatHost
        },
        data: {
            query: textPrompt
        }
    };
    return await new Promise((resolve) => {
        axios_1.default.request(options)
            .then((response) => {
            resData = { data: response.data };
        })
            .catch((error) => {
            resData = { data: JSON.stringify(error) };
        })
            .finally(() => {
            (0, utils_1.incrementRequestCount)();
            reply
                .header('Content-Type', 'application/json')
                .send(JSON.stringify(resData));
        });
    });
}
exports.generateChatFromText = generateChatFromText;
async function generateChatFromTextAlt(textPrompt, reply) {
    let resData = {};
    const options = {
        method: 'POST',
        url: app.config.chatFromTextServiceAlt.url,
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': apiSecrets.altApiChatKey,
            'X-RapidAPI-Host': apiSecrets.altApiChatHost
        },
        data: {
            query: textPrompt
        }
    };
    return await new Promise((resolve) => {
        axios_1.default.request(options)
            .then((response) => {
            resData = { data: response.data };
        })
            .catch((error) => {
            resData = { data: JSON.stringify(error) };
        })
            .finally(() => {
            (0, utils_1.incrementRequestCount)();
            reply
                .header('Content-Type', 'application/json')
                .send(JSON.stringify(resData));
        });
    });
}
exports.generateChatFromTextAlt = generateChatFromTextAlt;
async function analyzeSentimentFromText(textPrompt, reply) {
    let resData = {};
    const options = {
        method: 'POST',
        maxBodyLength: Infinity,
        url: app.config.sentimentAnalysisFromTextService.url,
        headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': apiSecrets.rapidApiSentimentAnalysisKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiSentimentAnalysisHost
        },
        data: [{
                id: crypto_1.default.randomUUID({ disableEntropyCache: true }),
                language: "en",
                text: textPrompt
            }]
    };
    return await new Promise((resolve) => {
        axios_1.default.request(options)
            .then((response) => {
            resData = { data: response.data };
        })
            .catch((error) => {
            resData = { data: JSON.stringify(error) };
        })
            .finally(() => {
            (0, utils_1.incrementRequestCount)();
            reply
                .header('Content-Type', 'application/json')
                .send(JSON.stringify(resData));
        });
    });
}
exports.analyzeSentimentFromText = analyzeSentimentFromText;
async function profanityCheck(textPrompt, reply) {
    let resData = {};
    const encodedParams = new URLSearchParams();
    encodedParams.set('content', textPrompt);
    encodedParams.set('censor-character', '*');
    const options = {
        method: 'POST',
        url: app.config.profanityCheckService.url,
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'X-RapidAPI-Key': apiSecrets.rapidApiProfanityCheckKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiProfanityCheckHost
        },
        data: encodedParams,
    };
    return await new Promise((resolve) => {
        axios_1.default.request(options)
            .then((response) => {
            resData = { data: response.data };
        })
            .catch((error) => {
            resData = { data: JSON.stringify(error) };
        })
            .finally(() => {
            (0, utils_1.incrementRequestCount)();
            reply
                .header('Content-Type', 'application/json')
                .send(JSON.stringify(resData));
        });
    });
}
exports.profanityCheck = profanityCheck;
async function emotionalCheck(textPrompt, reply) {
    let resData = {};
    const options = {
        method: 'POST',
        url: app.config.emotionalCheckService.url,
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'X-RapidAPI-Key': apiSecrets.rapidApiEmotionCheckKey,
            'X-RapidAPI-Host': apiSecrets.rapidApiEmotionCheckHost
        },
        form: {
            text: textPrompt
        }
    };
    return await new Promise((resolve) => {
        request(options, function (error, response, body) {
            if (error) {
                resData = { data: JSON.stringify(error) };
            }
            else {
                resData = { data: body };
            }
            (0, utils_1.incrementRequestCount)();
            reply.header('Content-Type', 'application/json').send(JSON.stringify(resData));
        });
    });
}
exports.emotionalCheck = emotionalCheck;
