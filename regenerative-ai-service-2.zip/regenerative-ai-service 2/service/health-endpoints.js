"use strict";
// health-endpoints.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestCount = exports.liveness = exports.readiness = void 0;
const utils_1 = require("./utils");
async function readiness(reply) {
    return await new Promise((resolve) => {
        (0, utils_1.incrementRequestCount)();
        reply.send('OK');
    });
}
exports.readiness = readiness;
async function liveness(reply) {
    return await new Promise((resolve) => {
        (0, utils_1.incrementRequestCount)();
        reply.send('OK');
    });
}
exports.liveness = liveness;
async function requestCount(reply) {
    return await new Promise((resolve) => {
        let resData = {};
        const xactCount = (0, utils_1.getRequestCount)();
        const timeScopedXactCount = (0, utils_1.getTimeScopedRequestCount)();
        resData = { requestCount: xactCount, timeScopedRequestCount: timeScopedXactCount };
        reply
            .header('Content-Type', 'application/json')
            .send(JSON.stringify(resData));
    });
}
exports.requestCount = requestCount;
