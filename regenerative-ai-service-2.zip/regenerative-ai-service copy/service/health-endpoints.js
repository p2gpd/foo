"use strict";
// health-endpoints.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestCount = exports.liveness = exports.readiness = void 0;
const utils_1 = require("./utils");
async function readiness(reply) {
    return await new Promise((resolve) => {
        (0, utils_1.incrementRequestCount)();
        reply.send('OK');
    });
}
exports.readiness = readiness;
async function liveness(reply) {
    return await new Promise((resolve) => {
        (0, utils_1.incrementRequestCount)();
        reply.send('OK');
    });
}
exports.liveness = liveness;
async function requestCount(reply) {
    return await new Promise((resolve) => {
        let resData = {};
        //const xactCount = getRequestCount()
        const timeScopedXactCount = (0, utils_1.getTimeScopedRequestCount)();
        //resData = <serviceMetrics> { requestCount: xactCount, timeScopedRequestCount: timeScopedXactCount}
        resData = timeScopedXactCount;
        reply
            //.header( 'Content-Type', 'application/json', )
            .header('Content-Type', 'text/html; charset=utf-8')
            .send(JSON.stringify(resData));
    });
}
exports.requestCount = requestCount;
