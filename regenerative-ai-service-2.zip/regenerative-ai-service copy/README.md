## regenerative-ai-service 

#### Description
###### I needed a service void of any AG First intellectual property to use on a containerization poc that involves outside vendors potentially handling some code artifacts. With our current interest in exploring ways that regenerative-AI can be applied within the bank, I decided to implement a regenerative-ai related service. The service can generate images (jpg/png), voice (mp3) & chatbox responses.  The service also provides sentiment analysis and profanity detection & removal capabilities capabilities that can be used on user-provide text input and generative chatbox responses.  The sentiment analysis feature can be used to switch dymanically switch regenerative-ai models to better suit the user and situation. The obsenity and profanity detection & removal capabilities can be used to find in appropriate words and phrases and potenially trigger enabling sentiment analysis on as needed basis service.

---

#### Routes
######  The regenerative-ai-service endpoint provides four(4) routes that expose a set of regenerative AI capabilities...
    1. generate images (jpg, png) using different AI models from text prompts / instructions
    2. generate chatbot responses (text) from text messages 
    3. generate voice (mp3) using different AI models from text prompts

###### The service also provides AI-based sentiment analysis and obsenity/profanity detection & redaction capabilities...  
    1. sentiment 
    1. obsenity

###### Health routes- a set of *health-oriented* routes that can be used by the kubernetes autoscaler to monitor the health of the service
    1. readiness
    2. liveness
---

#### Operation
##### Installation
    1. git clone https://github.com/p2gpd/regenerative-ai-service
    2. cd regenerative-ai-service
    3. npm install

##### Run the service
    1. cd regenerative-ai-service
    2. npm run build
    3. npm start (or npm run start-ts to use the ts-node runtime)

##### Run in a docker container (optional)
    1. cd regenerative-ai-service
    2. npm run build-all (builds service and container, optionally run npm run build and npm-build-container)
    3. npm run start-container
    
##### Configuration
    1. service port = service.port (defined in src/config.ts 8080=default)
    2. downstream API secrets: see secrets-vault.json

    
##### Testing the service
    1. run postman (install first is needed)
    2. import the postman collection 
        located at [project-home]\regenerative-ai-service\postman\generative-ai-service.postman_collection.json
    3. load the imported collection and verify the service is ready (to use by running the readiness, liveness and status routes)

#### Free License Limitations
	1. Chatgpt chat = 100 API calls per month
	2. Open AI chat = 100 API calls per month
	3. JoJ text to voice = 50 API calls per month
	4. Neutrino profanity detection = 50 API calls per day
	5. Segmind image generation models = 100 API calls per day
	6. Symanto sentiment analysis = 10,000 API calls per month
---

[TODO]
1. add support to switch regenerative-ai models
2. add unit tests
3. add swagger spec
4. add support for other languages
5. add sentiment analysis & obsenity/profanity analysis as an option in the regenerative apis
---

[tags]
*nodejs*, *typescript*, *fastify*, *regenerative ai*
