axios = require('axios'); 

let completedIterations = 0;
let timer

if ( process.argv.length < 3 ) {
    console.log('usage: node testdriver interations delay_in_seconds')
}

async function callReadinessEndpoint(iteration) {
    axios.get('http://172.16.36.4:8080/readiness') 
    .then(response => { 
        console.log(`readiness response:${response.data} interation: ${iteration}`) 
    }) 
    .catch(error => { 
        console.log(error)
    })
}
async function callLivenessEndpoint(iteration) {
    axios.get('http://172.16.36.4:8080/liveness') 
    .then(response => { 
        console.log(`liveness response:${response.data} interation: ${iteration}`) 
    }) 
    .catch(error => { 
        console.log(error)
    })
}
async function callEmotionalAnalysisEndpoint(iteration) {

    var data = JSON.stringify({
      "textPrompt": "After living abroad for such a long time, seeing my family was the best present I could have ever wished for"
    })
    
    var config = {
      method: 'post',
      timeout: 30000,
      url: 'http://172.16.36.4:8080/emotion',
      headers: { 
        'Authorization': 'Bearer 57da3444ca3d49cf905aae2aa97ad4a5', 
        'Content-Type': 'application/json'
      },
      data : data
    }
    
    await axios.post('http://172.16.36.4:8080/emotion', data, config)
    .then((response)  => {
      console.log(`emotion response:${JSON.stringify(response.data)} interation: ${iteration}`) 
    })
    .catch((error) => {
      console.log(error)
    })
}

async function processWorkload(numberOfInterations2Run) 
{
    if (completedIterations == numberOfInterations2Run) {
        clearTimeout(timer)
        console.log('complete')
        return
    } else {
        completedIterations++
        callReadinessEndpoint(completedIterations)
        callLivenessEndpoint(completedIterations)
        //callEmotionalAnalysisEndpoint(completedIterations)
    }
}

async function start() {
    const iterations = parseInt(process.argv[2])
    const interval = parseInt(process.argv[3]) * 1000
    console.log(`running ${iterations} iterations with a delay of ${interval/1000} secleconds between iterations`)
    timer = setInterval(processWorkload, interval, iterations)
}

start()