// generative-ai-service 

process.env.NODE_TLS_REJECT_UNAUTHORIZED='0'
import { fastify, FastifyReply, FastifyRequest } from 'fastify'
import {configureRoutes} from './route-setup'
import app = require('./config')  // our services configuration
import {startMetricsManager, incrementRequestCount} from './utils'

//setup the fastify comm stack
const { ADDRESS = '0.0.0.0', PORT = app.config.service.port } = process.env //8080
const server = fastify({
    logger: { level: 'info' }
})

// setup poc endpoint routes.....
configureRoutes(server)

server.addHook('onRequest', (request:FastifyRequest, reply:FastifyReply, done:any) => {
  server.log.info(`request before routing from ${request.ip}`)
  done()
})

// start the service
server.listen( { host: ADDRESS, port: parseInt(PORT, 10) }, (err:any, address:string) => {
  if (err) {
    console.error(err)
    process.exit(1)
  }
  startMetricsManager()
  server.log.info(`Started server at ${address}`)
})
