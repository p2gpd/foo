"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configureRoutes = void 0;
const health_endpoints_1 = require("./health-endpoints");
const route_handlers_1 = require("./route-handlers");
function configureRoutes(server) {
    // readiness probe endpoint (called by k8s)
    server.get('/readiness', async (request, reply) => {
        server.log.info("Incoming request at /readiness");
        (0, health_endpoints_1.readiness)(reply);
    });
    // readiness probe endpoint (called by k8s)
    server.get('/liveness', async (request, reply) => {
        server.log.info("Incoming request at /liveness");
        (0, health_endpoints_1.liveness)(reply);
    });
    // readiness probe endpoint (called by k8s)
    server.get('/request-count', async (request, reply) => {
        server.log.info("Incoming request at /request-count");
        (0, health_endpoints_1.requestCount)(reply);
    });
    // endpoint for generating images from a text prompt
    server.post('/gen-image', async (request, reply) => {
        server.log.info("Incoming request at /gen-image");
        const reqParams = request.body;
        const result = await (0, route_handlers_1.generateImageFromText)(reqParams.textPrompt, reqParams.profanityDetectionEnabled, reqParams.useRedacted);
        reply.header('Content-Type', 'application/json').send(JSON.stringify(result));
    });
    // endpoint for generating voice from a text prompt
    server.post('/gen-voice', async (request, reply) => {
        server.log.info('Incoming request at /gen-voice');
        const reqParams = request.body;
        const result = await (0, route_handlers_1.generateVoiceFromText)(reqParams.textPrompt, reply);
        reply.header('Content-Type', 'application/json').send(JSON.stringify(result));
    });
    // endpoint for generating chat responses from a text prompt
    server.post('/gen-chat', async (request, reply) => {
        server.log.info('Incoming request at /gen-chat');
        const reqParams = request.body;
        const result = await (0, route_handlers_1.generateChatFromText)(reqParams.textPrompt, reply);
        reply.header('Content-Type', 'application/json').send(JSON.stringify(result));
    });
    // endpoint for generating chat responses from a text prompt
    server.post('/gen-chat-alt', async (request, reply) => {
        server.log.info('Incoming request at /gen-chat-alt');
        const reqParams = request.body;
        const result = await (0, route_handlers_1.generateChatFromTextAlt)(reqParams.textPrompt, reply);
        reply.header('Content-Type', 'application/json').send(JSON.stringify(result));
    });
    // endpoint for sentiment analysis from a text prompt
    server.post('/sentiment', async (request, reply) => {
        server.log.info('Incoming request at /sentiment');
        const reqParams = request.body;
        const result = await (0, route_handlers_1.analyzeSentimentFromText)(reqParams.textPrompt, reply);
        reply.header('Content-Type', 'application/json').send(JSON.stringify(result));
    });
    // endpoint for obsenity check in a text prompt
    server.post('/obsenity', async (request, reply) => {
        server.log.info('Incoming request at /obsenity');
        const reqParams = request.body;
        const result = await (0, route_handlers_1.profanityCheck)(reqParams.textPrompt, reply);
        reply.header('Content-Type', 'application/json').send(JSON.stringify(result));
    });
    // endpoint for emotional check in a text prompt
    server.post('/emotion', async (request, reply) => {
        server.log.info('Incoming request at /emotion');
        const reqParams = request.body;
        const result = await (0, route_handlers_1.emotionalCheck)(reqParams.textPrompt, reply);
        reply.header('Content-Type', 'application/json').send(JSON.stringify(result));
    });
}
exports.configureRoutes = configureRoutes;
